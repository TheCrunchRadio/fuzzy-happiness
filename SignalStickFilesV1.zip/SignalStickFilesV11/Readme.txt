Thanks for purchasing the Signal Stick 2024.
This is inspired by the Ringway Manchester video on all of the
general radio frequencies that are busy with traffic that you
can load in to a radio.

Included is the following:

Excel Version: For general editing and putting into your radios.

Frequencies Only CSV (Transmit Disabled): This CSV file can be
imported into chirp and then uploaded to your radio. There is
over 500 frequencies so if you have a radio with less channels,
you may have to delete the ones you don't want. Transmit is
disabled on all of these frequencies.

Frequencies Only CSV (Transmit Enabled): This CSV file is as
above but transmit is enabled. NOTE: YOU MUST NOT TRANSMIT ON
ANY OF THESE FREQUENCIES WITHOUT THE RELEVANT LICENCE. IT IS
AGAINST THE LAW.

**I DO NOT ACCEPT ANY LIABILITY FOR LOSS OF DATA OR CORRUPTION TO YOUR
COMPUTER, FILES OR RADIOS. YOU USE THIS AT YOUR OWN RISK**

Thanks and enjoy!

Chris

For more on editing CSV files to suit other radios see here:
https://chirp.danplanet.com/projects/chirp/wiki/CSV_HowTo

Chirp programming software:
https://chirpmyradio.com/projects/chirp/wiki/Home