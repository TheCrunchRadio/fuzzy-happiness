This is the Flight Stick 2025.

Over 2000 frequencies include:

- All UK civil airports and airfields (Private airstrips included).
- Royal Air Force and USAF base air traffic control and operations.
- SAS, Ministry of Defence and Army Air Corps base air traffic control and operations.
- Royal Navy base air traffic control and operations.
- Air Defence.
- Common Frequencies (NATO, paragliding, parachuting, gliders, search and rescue).
- Offshore (oil and gas rigs).
- Control Zones (Swanwick Military, London Control, Scottish Control etc).
- All ROI and Northern Ireland airports and airfields (Private airstrips included).
- Volmets/ATIS.
- Heliports and Hospital helipads.

If you have a Baofeng or any radio scanner and don't know how to pick up air traffic control signals? This will give you everything you need.

There are files in here that you can edit in Excel to input to any radio. It can be used to edit and populate CSV files.

Included is the following on a 2gb memory stick.

Excel Document: Every frequency in one spreadsheet.

Excel Document: All frequencies divided into categories.

***NOTE: YOU MUST NOT TRANSMIT ON
ANY OF THESE FREQUENCIES WITHOUT THE RELEVANT LICENCE. IT IS
AGAINST THE LAW***

**I DO NOT ACCEPT ANY LIABILITY FOR LOSS OF DATA OR CORRUPTION TO YOUR
COMPUTER, FILES OR RADIOS. YOU USE THIS AT YOUR OWN RISK**

Make sure you have a good aerial on your radio too!

Thanks and enjoy!

Chris